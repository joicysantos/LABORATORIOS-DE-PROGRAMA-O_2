package lab4;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import lab4.Aluno;

public class TesteAluno {
	
	private Aluno aluno;
	private Aluno aluno1;
	
	@Before
	public void criaAluno() {
		aluno = new Aluno("116211305","Joicy","CC");
		aluno1 = new Aluno("116211304","Rita Lee","Musica");
	}
	@Test
	public void testaGetsDeAluno() {
		assertEquals("Matricula errada","116211305",aluno.getMatricula());
		assertEquals("Curso errado", "CC",aluno.getCurso());
		assertEquals("Nome errado","Joicy",aluno.getNome());
		
		assertEquals("Matricula errada","116211304",aluno1.getMatricula());
		assertEquals("Curso errado", "Geografia",aluno1.getCurso());
		assertEquals("Nome errado","Deus",aluno1.getNome());
	}
	@Test
	public void testarToString() {
		assertEquals("Erro na saida de dados","116211305 - Joicy - CC", aluno.toString());
		assertEquals("Erro na saida de dados","116211304 - Deus - Geografia", aluno1.toString());
	}
}

