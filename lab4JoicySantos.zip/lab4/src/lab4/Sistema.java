package lab4;

import java.util.ArrayList;
import java.util.Scanner;
/**
 * UNIVERSIDADE FEDERAL DE CAMPINA GRANDE
 * CIENCIA DA COMPUTACAO
 * @author Joicy dos Santos Silva - 116211305
 * joicy.silva@ccc.ufcg.edu.br
 */
public class Sistema {
	public static void main(String[] args) throws Exception {
		
		Scanner sc = new Scanner(System.in);
		ArrayList<Aluno> alunosQueResponderam = new ArrayList<>();
		GrupoDeEstudos mapaCadastraAluno = new GrupoDeEstudos();
		AlunosCadastrados alunos = new AlunosCadastrados();

		final String CADASTRAR = "C";
		final String EXIBIR = "E";
		final String NOVOGRUPO = "N";
		final String ALOCAROUIMPRIMIR = "A";
		final String REGISTRARRESPOSTA = "R";
		final String IMPRIMIR = "I";
		final String FECHAR = "O";
		String opcao;
		
		do {
			opcao = chamaMenu(sc);
			switch (opcao) {
			case CADASTRAR:
				cadastraAluno(sc, alunos);
				break;
			case EXIBIR:
				exibeAluno(sc, alunos);
				break;
			case NOVOGRUPO:
				cadastraGrupo(sc, mapaCadastraAluno);
				break;
			case ALOCAROUIMPRIMIR:
				System.out.print("(A)locar Aluno ou (I)mprimir Grupo? ");
				String opcoes = sc.nextLine().toUpperCase();
				if (opcoes.equals("A")) {
					alocarAluno(sc, mapaCadastraAluno, alunos);
				} else if (opcoes.equals("I")) {
					imprimeAlunos(sc, mapaCadastraAluno, alunos);
				}

				break;
			case REGISTRARRESPOSTA:
				cadastraAlunoRespondeu(sc, alunosQueResponderam, alunos);
				break;
			case IMPRIMIR:
				imprimirAlunoQueRespondeu(alunosQueResponderam);
				break;
			case FECHAR:
				break;
			default:
				System.out.println("ENTRADA INVALIDA!\n");
				System.out.println();
				break;
			}

		} while (!opcao.equals("O"));
	}
	private static void cadastraAluno(Scanner sc, AlunosCadastrados alunos) {
		System.out.print("Matricula: ");
		String matricula = sc.nextLine();
		System.out.print("Nome: ");
		String nome = sc.nextLine();
		System.out.print("Curso: ");
		String curso = sc.nextLine();
		
		Aluno aluno = new Aluno(matricula, nome, curso);
		try {
			alunos.cadastrarAluno(aluno);
			System.out.println("CADASTRO REALIZADO!\n");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	private static void exibeAluno(Scanner sc, AlunosCadastrados alunos) {

		System.out.print("Matricula: ");
		String matricula = sc.nextLine();
		try {
			System.out.println("Aluno: " + alunos.exibirAluno(matricula));

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	private static void alocarAluno(Scanner sc, GrupoDeEstudos mapaCadastraAluno, AlunosCadastrados alunos) {
		System.out.print("Matricula: ");
		String matricula = sc.nextLine();
		System.out.print("Grupo: ");
		String grupo = sc.nextLine();

		try {
			Aluno aluno = alunos.retornaAluno(matricula);
			mapaCadastraAluno.cadastrarAlunoNoGrupo(aluno, grupo);
			System.out.println("ALUNO ALOCADO!\n");

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	private static void imprimeAlunos(Scanner sc, GrupoDeEstudos mapaCadastraAluno, AlunosCadastrados alunos) {
		System.out.print("Grupo:");
		String tema = sc.nextLine().toUpperCase();
		System.out.println("Alunos do grupo " + tema.toUpperCase() + ":");

		try {
			System.out.print(mapaCadastraAluno.imprimirAluno(tema.toUpperCase()));
		} catch (Exception e) {
			System.out.print(e.getMessage());
		}
	}
	
	private static void cadastraAlunoRespondeu(Scanner sc, ArrayList<Aluno> alunosQueResponderam,
			AlunosCadastrados alunos) throws Exception {

		System.out.print("Matricula: ");
		String matricula = sc.nextLine();

		if (!alunos.isAlunoCadastrado(matricula)) {
			throw new Exception("ALUNO NÃO CADASTRADO!\n");
		}

		Aluno aluno = alunos.retornaAluno(matricula);
		alunosQueResponderam.add(aluno);
		System.out.println("ALUNO REGISTRADO!\n");
	}

	private static void imprimirAlunoQueRespondeu(ArrayList<Aluno> alunosQueResponderam)throws Exception {
		System.out.println("Alunos:");
		
		if(alunosQueResponderam.size() == 0) {
			throw new Exception("ALUNO NÃO CADASTRADO!\n");
		}
		
		for (int i = 0; i < alunosQueResponderam.size(); i++) {
			System.out.println(i + 1 + ". " + alunosQueResponderam.get(i).toString());
		}
	}
	
	private static void cadastraGrupo(Scanner sc, GrupoDeEstudos mapaCadastraGrupo) {
		System.out.print("Grupo: ");
		String tema = sc.nextLine().toUpperCase();
		try {
			mapaCadastraGrupo.cadastrarTema(tema);
			System.out.println("CADASTRO REALIZADO!\n");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	private static String chamaMenu(Scanner sc) {
		final String EXIBIRMENU = "(C)adastrar Aluno\n" + "(E)xibir Aluno\n" + "(N)ovo Grupo\n"
				+ "(A)locar Aluno no Grupo e Imprimir Grupos\n" + "(R)egistrar Resposta de Aluno\n"
				+ "(I)mprimir Alunos que Responderam\n" + "(O)ra, vamos fechar o programa!";
		System.out.println(EXIBIRMENU);
		System.out.println();
		System.out.print("Opcao> ");
		String opcao = sc.nextLine().toUpperCase();
		return opcao;
	}

}
