package lab4;

import java.util.HashMap;
/**
 * UNIVERSIDADE FEDERAL DE CAMPINA GRANDE
 * CIENCIA DA COMPUTACAO
 * 
 * Classe responsavel por representrar o cadastro de um@ alun@
 * 
 * @author Joicy dos Santos Silva - 116211305
 * joicy.silva@ccc.ufcg.edu.br
 *
 */

public class AlunosCadastrados {

	private HashMap<String,Aluno> mapaMatriculaAlunos; 
	public AlunosCadastrados() { 
		this.mapaMatriculaAlunos = new HashMap<>();
	}
	/**
	 * Metodo responsavel por cadastrar um@ determinad@ alun@
	 * @param passado como parametro o aluno
	 * @throws lancada uma excecao caso o alun@ ja esteja cadastrado.
	 */

	public void cadastrarAluno(Aluno aluno)throws Exception {
		if(isAlunoCadastrado(aluno.getMatricula())) { 
			throw new Exception("MATRÍCULA JÁ CADASTRADA!/n");
		}
		this.mapaMatriculaAlunos.put(aluno.getMatricula(),aluno);	
	}
	/**
	 * Metodo responsavel por retornar o aluno
	 * @param passado como parametro a matricula do aluno
	 * @return retorna o aluno
	 * @throws lancada uma excecao caso o aluno nao tenha sido cadastrado
	 */
	public Aluno retornaAluno(String matricula)throws Exception {
		
		if(isAlunoCadastrado(matricula)) {
			Aluno aluno = this.mapaMatriculaAlunos.get(matricula);
			return  aluno;
		}else {
			throw new Exception("ALUNO NÃO FOI CADASTRADO!\n");
		}
	}
	
	/**
	 * Metodo responsavel por verificar se o/a alun@ foi cadastrado
	 * @param passado como parametro a matricula do aluno
	 * @return retorna um booleano: true se o aluno foi cadastrado e false se ele nao foi
	 */
	public boolean isAlunoCadastrado(String matricula) {
		return this.mapaMatriculaAlunos.containsKey(matricula);
	}
	/**
	 * Metodo responsavel por exibir o aluno que foi cadastrado
	 * @param passado como paramentro a matricula do aluno
	 * @return retorna uma representacao textual do aluno
	 * @throws lancada uma excecao caso o aluno nao tenha sido cadastrado
	 */
	
	public String exibirAluno(String matricula)throws Exception { 
		return retornaAluno(matricula).toString();	
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mapaMatriculaAlunos == null) ? 0 : mapaMatriculaAlunos.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AlunosCadastrados other = (AlunosCadastrados) obj;
		if (mapaMatriculaAlunos == null) {
			if (other.mapaMatriculaAlunos != null)
				return false;
		} else if (!mapaMatriculaAlunos.equals(other.mapaMatriculaAlunos))
			return false;
		return true;
	}
	
}