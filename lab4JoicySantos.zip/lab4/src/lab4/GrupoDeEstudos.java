package lab4;

import java.util.HashMap;
import java.util.HashSet;
import java.util.ArrayList;

/**
 * UNIVERSIDADE FEDERAL DE CAMPINA GRANDE
 * CIENCIA DA COMPUTACAO
 * 
 * Classe responsavel por criar um grupo de estudos a partir de um@ alun@ cadastrad@ no sistema
 * a partir de sua matricula e curso.
 * 
 * @author Joicy dos Santos Silva - 116211305
 * joicy.silva@ccc.ufcg.edu.br
 *
 */
public class GrupoDeEstudos {
	private HashMap<String, HashSet<Aluno>> mapaCadastraGrupo;
	private ArrayList<String> temas;

	/**
	 * Construtor responsavel por iniciar a classe GrupoDeEstudos
	 */
	public GrupoDeEstudos() { 
		this.mapaCadastraGrupo = new HashMap<>();
		this.temas = new ArrayList<>();
	}
	/**
	 * Metodo responsavel por cadastrar um tema 
	 * @param passado como parametro o tema a ser cadastrado
	 * @throws lancada uma excecao caso o tema ja tenha sido cadastrado.
	 */

	public void cadastrarTema(String tema) throws Exception {

		if (isTemaCadastrado(tema.toUpperCase())) {
			throw new Exception("GRUPO JÁ CADASTRADO!\n");
		}
		HashSet<Aluno> alunos = new HashSet<>();
		this.temas.add(tema.toUpperCase());
		this.mapaCadastraGrupo.put(tema.toUpperCase(), alunos);
	}
	/**
	 * Metodo respondavel por cadastrar um aluno no grupo
	 * @param passado como parametro o aluno a ser cadastrado no grupo
	 * @param passado o tema a ser cadastrado
	 * @throws lancada uma excecao caso o grupo nao tenha sido cadastrado.
	 */

	public void cadastrarAlunoNoGrupo(Aluno aluno, String tema) throws Exception { // se o tema nao foi cadastrado eh
																					// lancado uma excecao.
		if (!isTemaCadastrado(tema.toUpperCase())) {
			throw new Exception("GRUPO NÃO CADASTRADO!\n");
		}
		HashSet<Aluno> alunosDesseTema = mapaCadastraGrupo.get(tema.toUpperCase());
		alunosDesseTema.add(aluno);
		mapaCadastraGrupo.put(tema.toUpperCase(), alunosDesseTema);
	}
	/**
	 * Metodo responsavel por verificar se o tema ja foi cadastrado
	 * @param passado como parametro o tema, para verificar se ele ja foi cadastrado
	 * @return retorna true se o tema foi cadastrado e false se não.
	 */

	public boolean isTemaCadastrado(String tema) {
		return this.mapaCadastraGrupo.containsKey(tema.toUpperCase());
	}
	/**
	 * Metodo responsavel por imprimir os alunos cadastardos
	 * @param passado como parametro o tema que foi cadastrado
	 * @return retorna uma representacao textual dos alunos que foram cadastrados
	 * @throws lancada uma excecao caso o grupo nao tenha sido cadastrado no sistema.
	 */
	public String imprimirAluno(String tema) throws Exception {
		if (!isTemaCadastrado(tema.toUpperCase())) {
			throw new Exception("GRUPO NÃO CADASTRADO!\n");
		}
		HashSet<Aluno> alunosDoTema = this.mapaCadastraGrupo.get(tema.toUpperCase());
		String retorno = "";
		for (Aluno aluno : alunosDoTema) {
			retorno += "* " + aluno.toString() + "\n";
		}
		return retorno; //retorna uma representacao textual do aluno
	}
}